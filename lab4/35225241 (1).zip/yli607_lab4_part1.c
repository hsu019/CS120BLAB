/*	Author: Yunxuan Li
 *  Partner(s) Name: 
 *	Lab Section: 22
 *	Assignment: Lab 3  Exercise 1
 *	Exercise Description: [optional - include for your own benefit]
 *
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */
#include <avr/io.h>
#ifdef _SIMULATE_
#include "simAVRHeader.h"
#endif

enum States{start, on_press, on_release, off_press, off_release}state;

void Tick(){
    switch (state) {
        case start:
            state = off_release;
            PORTB = 0x01;
            break;
        case off_release:
            if(PINA == 0x01){
                state = on_press;
                PORTB = 0x02;
            }
            else{
                state = off_release;
            }
            break;
        case on_press:
            if(PINA == 0x01){
                state = on_press;
                PORTB = 0x02;
            }
            else{
                state = on_release;
                PORTB = 0x02;
            }
            break;
        case on_release:
            if(PINA == 0x00){
                state = on_release;
            }
            else{
                state = off_press;
                PORTB = 0x01;
            }
            break;
        case off_press:
            if(PINA = 0x01){
                state = off_press;
                PORTB = 0x01;
            }
            else{
                state = off_release;
                PORTB = 0x01;
            }

            break;
            
        default:
            break;
    }

}


int main(void) {
    /* Insert DDR and PORT initializations */
    DDRA = 0x00;PORTA = 0xFF;
    DDRB = 0xFF;PORTB = 0x00;
    while(1){
        Tick();
    }
    return 0;
}
