/*	Author: Yunxuan Li
 *  Partner(s) Name: 
 *	Lab Section: 22
 *	Assignment: Lab 3  Exercise 1
 *	Exercise Description: [optional - include for your own benefit]
 *
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */
#include <avr/io.h>
#ifdef _SIMULATE_
#include "simAVRHeader.h"
#endif

enum States{start, init, wait, num_press, y_press, x_press, FI_press}state;
unsigned char door_open=0;
unsigned char check;
void Tick(){
    switch (state) {
        case start:
            state = init;
            break;
        case init:
            state = wait;
            break;
        case num_press:
            if(PINA == 0x04){
                state = num_press;
            }
            else if(PINA == 0x02){
                state = y_press;
            }
            else if(PINA == 0x01){
                state = x_press;
            }
            else if(PINA == 0x80){
                state = FI_press;
            }
            else{
                state = wait;
            }
            break;
        case x_press:
            if(PINA == 0x04){
               state = num_press;
           }
           else if(PINA == 0x02){
               state = y_press;
           }
           else if(PINA == 0x01){
               state = x_press;
           }
           else if(PINA == 0x80){
               state = FI_press;
           }
           else{
               state = wait;
           }
            break;
        case y_press:
            if(PINA == 0x04){
                state = num_press;
            }
            else if(PINA == 0x02){
                state = y_press;
            }
            else if(PINA == 0x01){
                state = x_press;
            }
            else if(PINA == 0x80){
                state = FI_press;
            }
            else{
                state = wait;
            }
            break;
        case FI_press:
            if(PINA == 0x04){
                state = num_press;
            }
            else if(PINA == 0x02){
                state = y_press;
            }
            else if(PINA == 0x01){
                state = x_press;
            }
            else if(PINA == 0x80){
                state = FI_press;
            }
            else{
                state = wait;
            }
            break;
        case wait:
            if(PINA == 0x04){
                state = num_press;
            }
            else if(PINA == 0x02){
                state = y_press;
            }
            else if(PINA == 0x01){
                state = x_press;
            }
            else if(PINA == 0x80){
                state = FI_press;
            }
            else{
                state = wait;
            }
            break;
        default:
            state = start;
            break;
    }
    switch (state) {
        case start:
            break;
        case init:
            PORTB = 0;
            PORTC = 0xFF;
            break;
        case num_press:
            check = 1;
            PORTC = 0x03;
            break;
        case x_press:
            if(check == 1){
                check = check + 1;
            }
            else if(check == 3){
                if(door_open){
                    PORTB = 0x00;
                    door_open = 0;
                    PORTC = door_open;
                    check = 0;
                }
                else if(!door_open){
                    PORTB = 0x01;
                    door_open = 1;
                    PORTC = door_open;
                    check = 0;
                }
            }
            else{
                check = 0;
            }
            PORTC = 0x01;
            break;
        case y_press:
            if(check == 0x02){
                check = check + 1;
            }
            else{
                check = 0;
            }
            break;
        case FI_press:
            PORTB = 0;
            PORTC = 0x04;
            check = 0;
            door_open = 0;
            break;
            
        case wait:
            break;
        default:
            break;
    }

}


int main(void) {
    /* Insert DDR and PORT initializations */
    DDRA = 0x00;PORTA = 0xFF;
    DDRB = 0xFF; PORTB = 0x00;
    DDRC = 0xFF;PORTC = 0x00;
    while(1){
        Tick();
    }
    return 0;
}
