/*	Author: Yunxuan Li
 *  Partner(s) Name: 
 *	Lab Section: 22
 *	Assignment: Lab 3  Exercise 1
 *	Exercise Description: [optional - include for your own benefit]
 *
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */
#include <avr/io.h>
#ifdef _SIMULATE_
#include "simAVRHeader.h"
#endif

enum States{start, init, wait, increase, decrease, reset}state;

unsigned char count;
unsigned char check;
void Tick(){
    switch (state) {
        case start:
            state = init;
            break;
        case init:
            state = wait;
            break;
        case increase:
            state = wait;
            check = 1;
            break;
        case decrease:
            state = wait;
            check = 1;
            break;
        case reset:
            state = wait;
            check = 1;
            break;
        case wait:
            if(PINA == 0x01 && !check){
               state = increase;
            }
            else if(PINA == 0x02&& !check){
               state = decrease;
            }
            else if(PINA == 0x03){
               state = reset;
            }
            else if(PINA == 0x00){
               check = 0;
               state = wait;
            }
            else{
                state = wait;
            }
            break;
        default:
            state = start;
            break;
    }
    switch (state) {
        case start:
            break;
        case init:
            count =0x07;
            PORTC = count;
            break;
        case increase:
            if(count <0x09){
                count++;
                PORTC = count;
            }
            else{
                PORTC = count;
            }
            break;
        case decrease:
            if(count > 0){
                count = count -1;
                PORTC = count;
            }
            else{
                PORTC = count;
            }
            break;
        case reset:
            count = 0;
            PORTC = count;
            break;
        case wait:
            PORTC = count;
            break;
        default:
            break;
    }

}


int main(void) {
    /* Insert DDR and PORT initializations */
    DDRA = 0x00;PORTA = 0xFF;
    DDRC = 0xFF;PORTC = 0x00;
    while(1){
        Tick();
    }
    return 0;
}
